import sys, unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "python"))

from app.agent.wake import WakeGate  # noqa: E402


class S:
    assistant_name = "Jarvis"
    wake_word = ""
    wake_required = True


def gate():
    return WakeGate(lambda: S())


class WakeTests(unittest.TestCase):
    def test_the_ways_a_recogniser_writes_hey_luna(self):
        for said, rest in [("hey jarvis open youtube", "open youtube"), ("heyjarvis what time is it", "what time is it"),
                           ("hey jar vis call mom", "call mom"), ("hey jarves open maps", "open maps"),
                           ("okay jarvis play music", "play music"), ("hey, Jarvis! call mom", "call mom")]:
            self.assertEqual(gate().process(said, now=1.0), ("command", rest), said)
        for bare in ["hey jarvis", "hello jarvis", "hey jarves", "hey jarvice", "hey jervis"]:
            self.assertEqual(gate().process(bare, now=1.0)[0], "awake", bare)

    def test_talk_in_the_room_is_still_ignored(self):
        for said in ["the moon is bright", "helena called me", "i like lunch", "hey lunch", "how are you doing"]:
            self.assertEqual(gate().process(said, now=1.0)[0], "ignore", said)

    def test_listener_has_watchdogs_and_a_spoken_hello(self):
        src = (Path(__file__).resolve().parents[1] / "app/src/main/java/com/luna/app/ListenService.java").read_text()
        self.assertIn("restartListening", src)
        self.assertIn("busySince", src)
        self.assertIn('"Yes?"', src)


if __name__ == "__main__":
    unittest.main()
