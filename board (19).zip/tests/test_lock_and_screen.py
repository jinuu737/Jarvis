import re
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app" / "src" / "main" / "python"))
from app.agent.fast import FastIntents  # noqa: E402

WEB = ROOT / "app/src/main/python/app/ui/web"


class Phone:
    def __init__(self, raw):
        self.raw = raw

    def read_screen(self):
        return self.raw

    def messages_enabled(self):
        return True


class ReadScreen(unittest.TestCase):
    def setUp(self):
        self.ai = []
        self.fast = FastIntents("android", Phone("ok: Instagram. Home. Home. Rahul sent a photo. 3 likes. . ... Reels. Like. Like"), None, {},
                                lambda q, c: self.ai.append(q) or "SUMMARY")

    def test_read_is_instant_and_never_waits_for_the_ai(self):
        for said in ("read my screen", "read out the screen", "read this page", "hey jarvis read my screen"):
            out = self.fast.match(said)
            self.assertIn("Rahul sent a photo", out.text, said)
            self.assertEqual(out.text.count("Home"), 1, said)  # repeats are dropped
        self.assertEqual(self.ai, [])

    def test_summaries_still_use_the_ai(self):
        self.assertIn("SUMMARY", self.fast.match("summarise my screen").text)
        self.assertEqual(len(self.ai), 1)


class Ui(unittest.TestCase):
    def test_photo_button_is_gone_and_playlists_and_lock_exist(self):
        html = (WEB / "index.html").read_text(encoding="utf-8")
        js = (WEB / "app.js").read_text(encoding="utf-8")
        for gone in ("attachBtn", "fileInput", "attachStrip", "S.photos"):
            self.assertNotIn(gone, html + js)
        for there in ('id="lockBtn"', 'id="playlistBtn"', 'id="lockScreen"'):
            self.assertIn(there, html)
        self.assertLess(html.index('id="playlistBtn"'), html.index('id="plannerBtn"'))

    def test_songs_are_stored_as_bytes_not_as_a_pointer(self):
        js = (WEB / "app.js").read_text(encoding="utf-8")
        self.assertIn("readBytes(file)", js)
        self.assertIn("new Blob([rec.data]", js)

    def test_lock_is_checked_before_anything_else_and_blocks_sending(self):
        js = (WEB / "app.js").read_text(encoding="utf-8")
        self.assertLess(js.index("Lock.init();"), js.index("tickClock();\n    setInterval(tickClock"))
        self.assertIn("if (S.locked) return;", js)

    def test_native_bridge_keeps_the_lock(self):
        java = (ROOT / "app/src/main/java/com/luna/app/MainActivity.java").read_text(encoding="utf-8")
        self.assertIn("public String getLock()", java)
        self.assertIn("public void setLock(String json)", java)


if __name__ == "__main__":
    unittest.main()
