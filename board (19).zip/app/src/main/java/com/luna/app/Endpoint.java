package com.luna.app;

import android.os.Handler;
import android.os.Looper;

/**
 * Decides when you have finished talking. The phone's own end-of-speech detection is unreliable (especially on Jarvis's own audio
 * feed), so listening could go on and on and never answer. Here, once words have appeared and then stop changing for a moment,
 * speech is over. A hard limit means no round can ever last forever.
 */
final class Endpoint {
    private static final long QUIET_MS = 650, NO_TEXT_MS = 8000, MAX_MS = 25000;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable onEnd;
    private String text = "";
    private long startedAt = 0, changedAt = 0;
    private boolean on = false;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!on) return;
            long now = System.currentTimeMillis();
            boolean done = startedAt > 0 && ((!text.isEmpty() && now - changedAt > QUIET_MS)
                    || (text.isEmpty() && now - startedAt > NO_TEXT_MS) || now - startedAt > MAX_MS);
            if (done) {
                on = false;
                onEnd.run();
            } else {
                h.postDelayed(this, 300);
            }
        }
    };

    Endpoint(Runnable onEnd) {
        this.onEnd = onEnd;
    }

    void begin() {
        on = true;
        h.postDelayed(tick, 300);
    }

    /** Called from any thread when the microphone itself has gone quiet after speech: finish now. */
    void fire() {
        h.post(() -> {
            if (!on) return;
            on = false;
            onEnd.run();
        });
    }

    /** The recogniser says speech began. */
    void heard() {
        if (startedAt == 0) startedAt = changedAt = System.currentTimeMillis();
    }

    /** What has been recognised so far. */
    void partial(String t) {
        if (t == null || t.equals(text)) return;
        text = t;
        changedAt = System.currentTimeMillis();
        if (startedAt == 0) startedAt = changedAt;
    }

    String text() {
        return text;
    }

    void stop() {
        on = false;
        h.removeCallbacks(tick);
    }
}
